<html>
    <head>
        <title>
            Login Here
        </title>
    </head>

    <body>
        <form action="proses05.php" method="POST" name="Input">
            <h2>Login here</h2>
            Username : <input type="text" name="username"><br>
            Password : <input type="password" name="password"><br>
            <input type="submit" name="Login" value="Login">
            <input type="reset" name="reset" value="Reset">
        </form>
    </body>
</html>
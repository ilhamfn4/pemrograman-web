<?php
    if (isset($_POST['Input'])) 
    {
        $nama = $_POST['nama'];
        echo "Nama Anda : <b>$nama</b>";
    }
?>
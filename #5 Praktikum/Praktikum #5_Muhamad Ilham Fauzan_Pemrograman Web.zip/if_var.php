<?php

$user = "";
if (!isset($user)) 
{
    echo "Variabel tidak ada/belum terbentuk";
}
else 
{
    echo "Variabel ada";
}

?>
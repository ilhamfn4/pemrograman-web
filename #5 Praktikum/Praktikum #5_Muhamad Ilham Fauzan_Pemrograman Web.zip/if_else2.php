<?php

$user = "achmatin";
$pass = "123";

if ($user == "achmatin" && $pass == "123") 
{
    echo "Login Berhasil";
}
else 
{
    echo "Login gagal";
}

?>
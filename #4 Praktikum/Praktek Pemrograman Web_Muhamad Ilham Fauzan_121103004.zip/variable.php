<?php
$nim = "121103004";
$nama = 'Muhamad Ilham Fauzan';

echo "NIM : ".$nim."<br>";
echo "Nama : $nama";
?>
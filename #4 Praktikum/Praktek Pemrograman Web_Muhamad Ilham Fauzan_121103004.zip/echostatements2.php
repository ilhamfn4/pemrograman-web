<!DOCTYPE html>
<html>
    <body>
    <?php
    $txt1 = "Pemrograman PHP";
    $txt2 = "Lab komputer";
    $x = 5;
    $y = 4;

    echo "<h2>".$txt1."</h2>";
    echo "Belajar PHP di ".$txt2."<br>"
    echo $x + $y;
    ?>
    </body>
</html>
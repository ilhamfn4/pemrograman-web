<!DOCTYPE html>
<html>
    <body>
    <?php
    /*
    This is multiple-line comment
    that spans over multiple
    lines
    */
    ?>
    </body>
</html>
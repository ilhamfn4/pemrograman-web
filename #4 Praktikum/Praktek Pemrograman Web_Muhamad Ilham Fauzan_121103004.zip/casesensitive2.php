<!DOCTYPE html>
<html>
    <body>

<?php
    $color = "red";
    echo "My car is ".$color."<br>";
    echo "My house is ".$color."<br>";
    echo "My boat is ".$color."<br>";
?>

    </body>
</html>
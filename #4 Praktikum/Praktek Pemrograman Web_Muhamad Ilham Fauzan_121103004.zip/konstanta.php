<?php
define("NAMA", "Muhamad Ilham Fauzan");
define("NILAI", 90);

//Nama = "Muhammad"; //Akan menyebabkan error
echo "Nama : ". NAMA;
echo "<br>Nilai : " . NILAI;
?>
<!DOCTYPE html>
<html>
    <body>

<?php
    echo "Hello Boy!<br>";
    echo "Hello Girl!<br>";
    echo "Hello Gay!<br>";
?>

    </body>
</html>
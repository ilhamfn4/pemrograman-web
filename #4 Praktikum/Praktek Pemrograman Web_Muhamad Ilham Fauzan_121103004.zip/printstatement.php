<!DOCTYPE html>
<html>
    <body>
    <?php
    echo "<h2>PHP is Fun!</h2>";
    echo "Hayoooo Gabung Kelas PHP";
    echo "Bukan Pemberi Harapan Palsu loh yaa!";
    ?>
    </body>
</html>
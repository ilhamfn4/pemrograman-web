<!DOCTYPE html>
<html>
    <body>
    <?php
    $txt = "Kelas Pemrograman Web";
    $x = 5;
    $y = 10.5;

    echo $txt;
    echo "<br>";
    echo $x;
    echo "<br>";
    echo $y;
    ?>
    </body>
</html>
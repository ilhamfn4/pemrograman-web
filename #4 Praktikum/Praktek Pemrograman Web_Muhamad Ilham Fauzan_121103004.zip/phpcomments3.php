<!DOCTYPE html>
<html>
    <body>
    <?php
    // You can also use comments to leave out parts of code line
    $x = 5 /* + 15 */ + 15;
    echo $x;
    ?>
    </body>
</html>
<!DOCTYPE html>
<html>
    <body>
    <?php
    $txt = "Three girls";
    echo "I love $txt";
    ?>
    </body>
</html>